var $dOut = $('#date'),
    $hOut = $('#hours'),
    $mOut = $('#minutes'),
    $sOut = $('#seconds'),
    $ampmOut = $('#ampm');
var months = [
  'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
];

var days = [
  'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
];

function update(){
  var date = new Date();
  
  var ampm = date.getHours() < 12
             ? 'AM'
             : 'PM';
  
  var hours = date.getHours() == 0
              ? 12
              : date.getHours() > 12
                ? date.getHours() - 12
                : date.getHours();
  
  var minutes = date.getMinutes() < 10 
                ? '0' + date.getMinutes() 
                : date.getMinutes();
  
  var seconds = date.getSeconds() < 10 
                ? '0' + date.getSeconds() 
                : date.getSeconds();
  
  var dayOfWeek = days[date.getDay()];
  var month = months[date.getMonth()];
  var day = date.getDate();
  var year = date.getFullYear();
  
  var dateString = dayOfWeek + ', ' + month + ' ' + day + ', ' + year;
  
  $dOut.text(dateString);
  $hOut.text(hours);
  $mOut.text(minutes);
  $sOut.text(seconds);
  $ampmOut.text(ampm);
} 

update();
window.setInterval(update, 1000);


// Sunrise & Sunset
var sunrise = new Date().sunrise(43.733850, -79.584420);
var sunset = new Date().sunset(43.733850, -79.584420);

//jQuery('.sunrise-btn').text(tConv24((sunrise.toString().match(/\d{2}:\d{2}/g))));
//jQuery('.sunrise-btn').text(tConv24((sunrise.toString().match(/\d{2}:\d{2}/g))));
jQuery('.sunrise-btn').text(tConv24(sunrise.toString().match(/\d{2}:\d{2}/g).toString()));
jQuery('.sunset-btn').text(tConv24(sunset.toString().match(/\d{2}:\d{2}/g).toString()));
jQuery('#maghrib').text(calculateMaghrib(sunset.toString().match(/\d{2}:\d{2}/g).toString()));

function tConv24(time24) {
  var ts = time24;
  var H = +ts.substr(0, 2);
  var h = (H % 12) || 12;
  //h = (h < 10)?("0"+h):h;  // leading 0 at the left for 1 digit hours
  var ampm = H < 12 ? " am" : " pm";
  ts = h + ts.substr(2, 3) + ampm;
  return ts;
};

function calculateMaghrib(time24) {
  console.log(time24);
  var ts = time24;
  var H = +ts.substr(0, 2);
  var M = +ts.substr(3, 4);
  var m = parseInt(M)+5;
  var h = (H % 12) || 12;
  if(m >= 60) {
    m = "00";
    h = h+1;
  }
  m = (m < 10)?("0"+m):m  
  //h = (h < 10)?("0"+h):h;  // leading 0 at the left for 1 digit hours
  var ampm = H < 12 ? " am" : " pm";
  ts = h +":"+ m + ampm;
  return ts;
}

// Today's Date
var date=new Date();

var months=["JAN","FEB","MAR","APR","MAY","JUN","JUL", "AUG","SEP","OCT","NOV","DEC"];
var val=date.getDate()+" "+months[date.getMonth()]+" "+date.getFullYear();
jQuery("#printDate").text(val);
